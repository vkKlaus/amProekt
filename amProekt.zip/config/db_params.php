<?php

return array(
    'host' => 'localhost',
    'dbname' => 'amproekt',
    'user' => 'root',
    'password' => '',
);
