

<footer id="footer" class="page-footer"><!--Footer-->
   <p>ЗА 6 ЛЕТ ЗАПРОЕКТИРОВАННО    300 725м<sup>2</sup></p>
</footer><!--/Footer-->
<script src="/template/js/all.min.js"></script>
<script src="/template/js/jquery-3.4.1.min.js"></script>
<script src="/template/js/jquery.fancybox.min.js"></script>
</body>
</html>