<?php include ROOT . '/views/layouts/header.php'; ?>
<h1>Рисунок из галереи</h1>
<a href="#" OnClick="history.back();">Назад</a>

<img src=<?php echo $imgPath ?> alt="">
<?php include ROOT . '/views/layouts/footer.php'; ?>